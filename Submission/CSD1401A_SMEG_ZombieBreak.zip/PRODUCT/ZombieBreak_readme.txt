Game Name: Zombie Break
Team Name: SMEG

Class: Fall 2022 CSD1401 A
========================================================================
Team Members:
Sen Chuan Tay	(t.senchuan@digipen.edu)
Michael Mah 	(m.mah@digipen.edu)
Edgar Yong 	(y.yiphanedgar@digipen.edu)
Geoffrey Cho 	(g.cho@digipen.edu)
========================================================================


Game Controls:
  W
A S D  To move

Hold Left Mouse Click to shoot
Pressing "Esc" will pause the game.

Keep Shooting. Your Health Will keep draining.
Killing Mobs will regenerate some health.
Items give temporary stat boost