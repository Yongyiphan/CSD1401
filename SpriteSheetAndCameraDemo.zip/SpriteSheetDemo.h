#pragma once

void SpriteSheetDemo_Init(void);
void SpriteSheetDemo_Update(void);
void SpriteSheetDemo_Exit(void);