#pragma once
void CameraDemo_Init(void);
void CameraDemo_Update(void);